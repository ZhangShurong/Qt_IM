#include "listwidget_chatmsgcontent.h"

listWidget_chatMsgContent::listWidget_chatMsgContent(QWidget *parent) : QListWidget(parent)
{

}
