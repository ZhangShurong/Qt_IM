#ifndef USERENTITY_H
#define USERENTITY_H


class UserEntity : public aaa
{
public:
    UserEntity();
};

#endif // USERENTITY_H