#include "chatnowlistview.h"

ChatNowListView::ChatNowListView(QWidget *parent) : QListView(parent)
{

}
