#ifndef SELFUSERINFO_H
#define SELFUSERINFO_H

#include <QWidget>
#include <QDialog>

class SelfUserInfo : public QDialog
{
    Q_OBJECT
public:
    explicit SelfUserInfo(QWidget *parent = 0);
    ~SelfUserInfo();

signals:

public slots:

private:

};

#endif // SELFUSERINFO_H
