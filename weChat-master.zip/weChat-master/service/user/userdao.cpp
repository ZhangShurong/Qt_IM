#include "userdao.h"

UserDao::UserDao(QObject *parent) : QObject(parent)
{

}
