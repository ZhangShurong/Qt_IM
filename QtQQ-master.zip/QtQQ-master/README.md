# 仿QQ即时通讯程序
这是我们软件工程一个大作业

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/1.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/2.png)

登录

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/3.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/5.png)

主界面

模拟了QQ的窗口隐藏和托盘系统图标功能，包括图标闪烁效果和语音提示效果

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/6.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/8.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/11.png)

下面是一些基本的窗口展示

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/7.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/9.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/10.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/12.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/13.png)

更多信息请用Qt creator打开查看




