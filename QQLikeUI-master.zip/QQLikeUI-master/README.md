#QQLikeUI
qt版本：5.3.2 编译器：mingw32

登录窗体与主窗体已经部分实现，窗体目前还不能自由改变大小，但是可以随意拖动。


主界面对比，左边为原版，右边为“山寨”：

![](http://git.oschina.net/kyyblabla/QQLikeUI/raw/master/%E5%AF%B9%E6%AF%94%E5%9B%BE2.png)


登录窗口对比，左边为原版，右边为“山寨”：
![](http://git.oschina.net/kyyblabla/QQLikeUI/raw/master/%E8%BF%90%E8%A1%8C%E5%AF%B9%E6%AF%94.jpg)